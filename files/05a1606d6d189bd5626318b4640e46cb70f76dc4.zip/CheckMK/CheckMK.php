<?php namespace App\SupportedApps\CheckMK;

class CheckMK extends \App\SupportedApps {

}