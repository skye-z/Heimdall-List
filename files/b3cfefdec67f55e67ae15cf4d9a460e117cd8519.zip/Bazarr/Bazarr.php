<?php namespace App\SupportedApps\Bazarr;

class Bazarr extends \App\SupportedApps {

}