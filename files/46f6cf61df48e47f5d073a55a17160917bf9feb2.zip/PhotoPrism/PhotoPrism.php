<?php namespace App\SupportedApps\PhotoPrism;

class PhotoPrism extends \App\SupportedApps {

}