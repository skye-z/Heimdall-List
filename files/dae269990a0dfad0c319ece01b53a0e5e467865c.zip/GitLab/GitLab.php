<?php namespace App\SupportedApps\GitLab;

class GitLab extends \App\SupportedApps {

}