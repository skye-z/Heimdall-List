<?php namespace App\SupportedApps\Monica;

class Monica extends \App\SupportedApps {

}