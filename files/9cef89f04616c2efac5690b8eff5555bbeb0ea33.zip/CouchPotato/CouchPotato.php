<?php namespace App\SupportedApps\CouchPotato;

class CouchPotato extends \App\SupportedApps {

}