<?php namespace App\SupportedApps\Oscarr;

class Oscarr extends \App\SupportedApps {

}