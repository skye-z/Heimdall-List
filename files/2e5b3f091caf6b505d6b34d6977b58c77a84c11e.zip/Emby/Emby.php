<?php namespace App\SupportedApps\Emby;

class Emby extends \App\SupportedApps {

}