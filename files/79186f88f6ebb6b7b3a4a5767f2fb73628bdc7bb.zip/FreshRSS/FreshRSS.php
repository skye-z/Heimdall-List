<?php namespace App\SupportedApps\FreshRSS;

class FreshRSS extends \App\SupportedApps {

}