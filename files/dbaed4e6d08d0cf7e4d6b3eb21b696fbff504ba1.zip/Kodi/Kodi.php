<?php namespace App\SupportedApps\Kodi;

class Kodi extends \App\SupportedApps {

}