<ul class="livestats">
    <li>
        <span class="title">Avg. Response Time</span>
        <strong>{!! $time_output !!}</strong>
    </li>
</ul>