<?php namespace App\SupportedApps\openmediavault;

class openmediavault extends \App\SupportedApps {

}