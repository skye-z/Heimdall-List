<?php namespace App\SupportedApps\Shaarli;

class Shaarli extends \App\SupportedApps {

}