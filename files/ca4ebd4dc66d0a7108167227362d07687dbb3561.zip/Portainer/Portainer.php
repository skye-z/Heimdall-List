<?php namespace App\SupportedApps\Portainer;

class Portainer extends \App\SupportedApps {

}