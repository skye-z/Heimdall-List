<ul class="livestats">
    <li>
        <span class="title">Today</span>
        <strong>{!! $today !!}</strong>
    </li>
    <li>
        <span class="title">Usage</span>
        <strong>{!! $usage !!}</strong>
    </li>
</ul>
