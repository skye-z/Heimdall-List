<ul class="livestats">
    <li style="width:50%;">
        <span class="title">DOWN ↓</span>
        <strong>{!! $down_rate !!}</strong>
    </li>
    <li>
        <span class="title">UP ↑</span>
        <strong>{!! $up_rate !!}</strong>
    </li>
</ul>
