<?php namespace App\SupportedApps\Ghost;

class Ghost extends \App\SupportedApps {

}