<?php namespace App\SupportedApps\Syncthing;

class Syncthing extends \App\SupportedApps {

}