<?php namespace App\SupportedApps\FlexGet;

class FlexGet extends \App\SupportedApps {

}
