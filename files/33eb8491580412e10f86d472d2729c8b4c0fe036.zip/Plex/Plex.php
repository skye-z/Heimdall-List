<?php namespace App\SupportedApps\Plex;

class Plex extends \App\SupportedApps {

}