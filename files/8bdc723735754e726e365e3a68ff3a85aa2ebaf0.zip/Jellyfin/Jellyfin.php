<?php namespace App\SupportedApps\Jellyfin;

class Jellyfin extends \App\SupportedApps {

}