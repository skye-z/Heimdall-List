<?php namespace App\SupportedApps\Nextcloud;

class Nextcloud extends \App\SupportedApps {

}