<?php namespace App\SupportedApps\Freenas;

class Freenas extends \App\SupportedApps {

}