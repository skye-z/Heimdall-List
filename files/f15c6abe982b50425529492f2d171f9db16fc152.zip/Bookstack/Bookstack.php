<?php namespace App\SupportedApps\Bookstack;

class Bookstack extends \App\SupportedApps {

}