<?php namespace App\SupportedApps\SearxMetasearchEngine;

class SearxMetasearchEngine extends \App\SupportedApps {

}